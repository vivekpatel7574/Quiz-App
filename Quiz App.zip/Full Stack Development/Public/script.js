// When the page loads, fetch quiz data
const topic = 'science';  // Example topic
const quizContainer = document.getElementById('quiz-container');

fetch(`/quiz/${topic}`)
    .then(response => response.json())
    .then(data => {
        console.log(data);  // Log the received quiz data to the console

        data.forEach((question, index) => {
            const questionElement = document.createElement('div');
            questionElement.classList.add('question');
            questionElement.innerHTML = `
                <p>${index + 1}. ${question.question}</p>
                <div>
                    ${question.options.map(option => `
                        <label>
                            <input type="radio" name="q${index}" value="${option}">
                            ${option}
                        </label>
                    `).join('')}
                </div>
            `;
            quizContainer.appendChild(questionElement);
        });
    })
    .catch(error => console.error('Error fetching quiz data:', error));

// Submit button logic to show the score
document.getElementById('submit-btn').addEventListener('click', () => {
    const answers = [];
    // Collect selected answers
    document.querySelectorAll('.question').forEach((question, index) => {
        const selectedOption = question.querySelector('input:checked');
        if (selectedOption) {
            answers.push(selectedOption.value);
        } else {
            answers.push(null); // Handle case where no answer is selected
        }
    });

    // Check if all questions are answered
    if (answers.includes(null)) {
        alert("Please answer all questions before submitting.");
        return;
    }

    // Send answers to the backend for scoring
    fetch('/score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answers, topic })
    })
    .then(response => response.json())
    .then(data => {
        const { score, results } = data;

        // Display the score
        document.getElementById('score-container').innerText = `Your score: ${score}/${results.length}`;

        // Display the correct/incorrect results
        const resultContainer = document.createElement('div');
        results.forEach(result => {
            const resultElement = document.createElement('div');
            resultElement.innerHTML = `
                <p><strong>${result.question}</strong></p>
                <p>Your answer: ${result.user_answer}</p>
                <p>Correct answer: ${result.correct_answer}</p>
                <p>${result.is_correct ? 'Correct' : 'Incorrect'}</p>
            `;
            resultContainer.appendChild(resultElement);
        });

        document.body.appendChild(resultContainer); // Append the results to the body
    })
    .catch(error => console.error('Error submitting answers:', error));
});
