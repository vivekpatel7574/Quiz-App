const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Enable CORS
app.use(cors());

// Serve static files (index.html, CSS, JS)
app.use(express.static(path.join(__dirname, 'public')));

// Parse JSON bodies for POST requests
app.use(express.json());

// Route to serve the index.html page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Endpoint to fetch quiz questions based on the topic
app.get('/quiz/:topic', (req, res) => {
    const topic = req.params.topic;
    fs.readFile(`./data/${topic}.json`, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Error reading file');
        }
        const questions = JSON.parse(data);
        res.json(questions);
    });
});

// Endpoint to calculate the score based on the user's answers
app.post('/score', (req, res) => {
    const userAnswers = req.body.answers; // Array of user's answers
    const topic = req.body.topic; // The topic of the quiz
    fs.readFile(`./data/${topic}.json`, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Error reading file');
        }
        const questions = JSON.parse(data);

        let score = 0;
        const results = questions.map((question, index) => {
            const isCorrect = userAnswers[index] === question.correct_answer;
            if (isCorrect) score++;  // Increase score if the answer is correct
            return {
                question: question.question,
                correct_answer: question.correct_answer,
                user_answer: userAnswers[index],
                is_correct: isCorrect
            };
        });

        res.json({ score, results });
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
